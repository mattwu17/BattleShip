package model;

public class BattleShip {
	private BattlePlayer p1, p2;
	private static final String RULES = "Battleship. You know the rules.\n";
	
	public BattleShip(String name1, String name2) {
		p1 = new BattlePlayer(name1);
		p2 = new BattlePlayer(name2);
	}
	
	public BattlePlayer getP1() {
		return p1;
	}
	
	public BattlePlayer getP2() {
		return p2;
	}
	
	public static void displayRules() {
		System.out.println(RULES);
	}
	
	public boolean validMove(BattlePlayer opponent, String move) {
		if (move == null || move.length() < 2 || move.length() > 3 || 
		move.charAt(0) < 65 || move.charAt(0) > 74){
			return false;
		}
		
		int row, col;
		char rowChar = move.charAt(0);
		row = rowCharToInt(rowChar);
		
		//checks if rest of String after first character is an integer
		try {
			col = Integer.parseInt(move.substring(1)) - 1;
		} catch (NumberFormatException e) {
			return false;
		}
		
		//checks if row and col are in bounds
		if (row < 0 || col < 0 || row > 9 || col > 9) {
			return false;
		}
		
		char moveChar = opponent.getBoard().getBoard()[row][col];
		char miss = BattleBoard.getMiss();
		char hit = BattleBoard.getHit();

		//checks if move has been entered before
		if (moveChar == hit || moveChar == miss) {
			System.out.println("Move already entered");
			return false;
		} 

		return true;
	}
	
	public void addMove(BattlePlayer opponent, String move) {
		int row, col;
		char rowChar = move.charAt(0);
		row = rowCharToInt(rowChar);
		col = Integer.parseInt(move.substring(1)) - 1;
		char moveChar = opponent.getBoard().getBoard()[row][col];
		
		if (moveChar == BattleBoard.getEmpty()) {
			opponent.getBoard().getBoard()[row][col] = BattleBoard.getMiss();
			System.out.println("Shot missed");
		} else {
			opponent.getBoard().getBoard()[row][col] = BattleBoard.getHit();
			System.out.println("Shot hit");
			opponent.hitByShot();
			
			switch (moveChar) {
			case 'A':
				opponent.getBoard().getShips()[0].addHit();
				break;
			case 'B':
				opponent.getBoard().getShips()[1].addHit();
				break;
			case 'C':
				opponent.getBoard().getShips()[2].addHit();
				break;
			case 'D':
				opponent.getBoard().getShips()[3].addHit();
				break;
			case 'S':
				opponent.getBoard().getShips()[4].addHit();				
				break;
			}	
		}	
	}
	
	public void displayBoard(BattlePlayer opponent) {
		System.out.println(opponent.getName() + "\'s Board:");
		char[][] uncensoredBoard = opponent.getBoard().getBoard();
		char[][] censoredBoard = new char[BattleBoard.getDefaultRows()]
				[BattleBoard.getDefaultCols()];
		
		for (int rows = 0; rows < BattleBoard.getDefaultRows(); rows++) {
			for (int cols = 0; cols < BattleBoard.getDefaultCols(); cols++) {
				if (uncensoredBoard[rows][cols] != BattleBoard.getMiss() &&
						uncensoredBoard[rows][cols] != BattleBoard.getHit()) {
					censoredBoard[rows][cols] = BattleBoard.getEmpty();
				} else {
					censoredBoard[rows][cols] = uncensoredBoard[rows][cols];
				}
				System.out.print(censoredBoard[rows][cols] + " ");
			}
			System.out.println();
		}
	}
	
	//identifies when the loser takes a fatal shot
	public boolean gameOver() {
		int maxShots = BattleBoard.getMaxShots();
		boolean isGameOver = false;

		if (p1.getShotsHit() == maxShots) {
			System.out.println(p2.getName() + " wins!");
			isGameOver = true;
		} else if (p2.getShotsHit() == maxShots) {
			System.out.println(p1.getName() + " wins!");
			isGameOver = true;
		}
		
		return isGameOver;
	}
	
	private static int rowCharToInt(char rowChar) {
		int row;
		
		switch (rowChar) {
		case 'A':
			row = 0; 
			break;
		case 'B':
			row = 1;
			break;
		case 'C':
			row = 2;
			break;
		case 'D':
			row = 3;
			break;
		case 'E':
			row = 4;
			break;
		case 'F':
			row = 5;
			break;
		case 'G':
			row = 6;
			break;
		case 'H':
			row = 7;
			break;
		case 'I':
			row = 8;
			break;
		case 'J':
			row = 9;
			break;
		default:
			row = 10;
		}
		
		return row;
	}
}
