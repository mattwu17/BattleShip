package model;

public class BattlePlayer {
	private String name;
	private BattleBoard board;
	private int shotsHit;
	
	public BattlePlayer(String name) {	
		this.name = name;
		this.board = new BattleBoard();
		this.shotsHit = 0;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public BattleBoard getBoard() {
		return board;
	}
	
	public int getShotsHit() {
		return shotsHit;
	}
	
	public void hitByShot() {
		shotsHit++;
	}
}
