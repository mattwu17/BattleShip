package model;

import java.util.Scanner;

public class BattleDriver {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BattleShip.displayRules();
		System.out.println("Player 1, Enter name: ");
		String name1 = sc.next();
		System.out.println("Player 2, Enter name: ");
		String name2 = sc.next();
		BattleShip game = new BattleShip(name1, name2);
		BattlePlayer currentPlayer;
		BattlePlayer opponent;
		
		int turnNumber = (int) (Math.random() * 2);

		//loops until the game is over
		do {
			if (turnNumber % 2 == 1) {
				currentPlayer = game.getP1();
				opponent = game.getP2();
			} else {
				currentPlayer = game.getP2();
				opponent = game.getP1();
			}
			
			turnNumber++;
			
			System.out.println(currentPlayer.getName() + "\'s Turn, Enter Move:");
			
			String move = sc.next();
			
			while (!game.validMove(opponent, move)) {
				System.out.println("Invalid move, please try again.");
				move = sc.next();
			}
			
			game.addMove(opponent, move);
			game.displayBoard(opponent);
		} while (!game.gameOver());
		
		sc.close();
	}
}
