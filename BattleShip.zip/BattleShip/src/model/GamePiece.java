package model;

public class GamePiece {
	private String name;
	private int length;
	private int position;
	private int orientation;
	private int hits;
	private char shipChar;
	
	public GamePiece(String name, int length, char shipChar) {
		this.name = name;
		this.length = length;
		this.position = 100;
		this.orientation = 5;
		this.hits = 0;
		this.shipChar = shipChar;
	}
	
	public String getName() {
		return name;
	}
	
	public int getLength() {
		return length;
	}
	
	public int getPosition() {
		return position;
	}
	
	public int getOrientation() {
		return orientation;
	}
	
	public char getShipChar() {
		return shipChar;
	}
	
	public void setPosition(int position) {
		this.position = position;
	}
	
	public void setOrientation(int orientation) {
		this.orientation = orientation;
	}
	
	public void addHit() {
		hits++;
		
		if (hits == length) {
			System.out.println("You sunk the " + name + "!");
		}
	}
}
