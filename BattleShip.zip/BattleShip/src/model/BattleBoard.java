package model;

import java.util.Random;
import java.util.stream.IntStream;

public class BattleBoard {
	private static final String[] SHIPS_NAME = {"Aircraft Carrier", "Battleship"
			, "Cruiser", "Destroyer", "Submarine"};
	private static final int[] SHIPS_SIZE = {6, 5, 4, 3, 2};
	private static final char[] SHIPS_CHAR = {'A', 'B', 'C', 'D', 'S'};
	private static final int MAX_SHOTS = IntStream.of(SHIPS_SIZE).sum();
	private static final int DEFAULT_ROWS = 10, DEFAULT_COLS = 10;
	private static final char EMPTY = '.', MISS = '0', HIT = '$';
	private GamePiece[] ships;
	private char[][] board;

	public BattleBoard() {
		char[][] board = new char[DEFAULT_ROWS][DEFAULT_COLS];

		//fills every spot on the board with empty spaces
		for (int rows = 0; rows < DEFAULT_ROWS; rows++) {
			for (int cols = 0; cols < DEFAULT_COLS; cols++) {
				board[rows][cols] = EMPTY;
			}
		}

		this.board = board;

		//creates valid ships for lengths in provided array and adds to board
		int length = SHIPS_SIZE.length;
		this.ships = new GamePiece[length];

		for (int i = 0; i < length; i++) {
			GamePiece piece = new GamePiece(SHIPS_NAME[i], SHIPS_SIZE[i], 
					SHIPS_CHAR[i]);
			boolean validShip = false;

			do {
				piece.setPosition((int) (Math.random() * 100));
				piece.setOrientation((int) (Math.random() * 4));

				validShip = (inBounds(piece) && noOverlap(piece));

				if (validShip) {
					//adds to ships array, then adds characters to board
					ships[i] = piece;
					addPiece(piece);
				}
			} while (!validShip);
		}
	}

	/*
	 * 0 is facing right, goes counterclockwise
	 */
	private boolean inBounds(GamePiece piece) {
		int length = piece.getLength() - 1;
		int position = piece.getPosition();
		int row = position / 10;
		int col = position % 10;
		
		try {
			char testChar;
			
			switch (piece.getOrientation()) {
			case 0:
				testChar = board[row][col + length];
				break;
			case 1:
				testChar = board[row - length][col];
				break;
			case 2:
				testChar = board[row][col - length];
				break;
			default:
				testChar = board[row + length][col];
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			return false;
		}
		
		return true;
	}

	private boolean noOverlap(GamePiece piece) {
		int length = piece.getLength();
		int position = piece.getPosition();
		int row = position / 10;
		int col = position % 10;

		for (int i = 0; i < length; i++) {
			switch (piece.getOrientation()) {
			case 0:
				if (board[row][col + i] != EMPTY) {
					return false;
				}

				break;
			case 1:
				if (board[row - i][col] != EMPTY) {
					return false;
				}
				
				break;
			case 2:
				if (board[row][col - i] != EMPTY) {
					return false;
				}
				
				break;
			default:
				if (board[row + i][col] != EMPTY) {
					return false;
				}
			}
		}
		
		return true;
	}

	private void addPiece(GamePiece piece) {
		int length = piece.getLength();
		int position = piece.getPosition();
		int row = position / 10;
		int col = position % 10;

		for (int i = 0; i < length; i++) {
			switch (piece.getOrientation()) {
			case 0:
				board[row][col + i] = piece.getShipChar();
				break;
			case 1:
				board[row - i][col] = piece.getShipChar();
				break;
			case 2:
				board[row][col - i] = piece.getShipChar();
				break;
			default:
				board[row + i][col] = piece.getShipChar();
			}
		}
	}
	
	public char[][] getBoard() {
		return board;
	}

	public GamePiece[] getShips() {
		return ships;
	}
	
	public static int getMaxShots() {
		return MAX_SHOTS;
	}

	public static char getEmpty() {
		return EMPTY;
	}
	
	public static char getMiss() {
		return MISS;
	}
	
	public static char getHit() {
		return HIT;
	}
	
	public static int getDefaultRows() {
		return DEFAULT_ROWS;
	}
	
	public static int getDefaultCols() {
		return DEFAULT_COLS;
	}

	@Override
	public String toString() {
		String boardString = "";

		for (int rows = 0; rows < board.length; rows++) {
			for (int cols = 0; cols < board[rows].length; cols++) {
				boardString += board[rows][cols] + " ";
			}
			boardString += "\n";
		}

		return boardString;
	}
}
