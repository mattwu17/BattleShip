package tests;

import org.junit.Test;

import model.BattleBoard;
import model.BattlePlayer;
import model.BattleShip;

public class StudentTests {
	 
	@Test
	public void testBattleBoardConstructor() {
		BattleBoard testBoard = new BattleBoard();
		
		System.out.println(testBoard.toString());
	}
	
}
